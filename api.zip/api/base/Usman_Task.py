
from reportlab.platypus.flowables import KeepTogether
from reportlab.lib import colors
from reportlab.platypus import TableStyle, Table
from reportlab.platypus.flowables import KeepTogether
from reportlab.lib import colors
from reportlab.platypus import TableStyle, Table

from .pdfReport import pdfReport
from reportlab.platypus import Spacer, Paragraph
from reportlab.lib.units import inch, cm
from reportlab.lib.styles import getSampleStyleSheet  
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus.flowables import KeepTogether
from .pdfReport import pdfReport
from reportlab.platypus import Spacer, Paragraph
from reportlab.lib.units import inch, cm
from reportlab.lib.styles import getSampleStyleSheet  
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import Paragraph
from reportlab.lib.styles import getSampleStyleSheet
import os
from .pdfReport import pdfReport
from reportlab.platypus import Spacer, Paragraph  
from reportlab.lib.styles import getSampleStyleSheet

ip_range = []
pdf_report = pdfReport()

def pdf_generate(dict_data):
    data = [[], ]

    style = getSampleStyleSheet()
    yourStyle = ParagraphStyle('yourtitle',
                               fontName="Helvetica-Bold",
                               fontSize=16,
                               parent=style['Heading2'],
                               alignment=1,
                               spaceAfter=14)
    data = [[], ]  # Un-installed Softwares
    header20 = Paragraph(
        "<bold  align= center ><font size=18><u>Ip_Range Report</u></font></bold>", yourStyle)
    # ip_range.append(KeepTogether(header20))  # Style is Remaining
    # ip_range.append(KeepTogether(Spacer(1, 0.5 * cm)))
    row = 0
    for dictionary in dict_data:
        # Access individual dictionary items
        ip = dictionary['ip']
        data.append([Paragraph(ip), Paragraph("Data")])
        for key, value in dictionary.items():
            # print(key, ":", value)
            data.append([Paragraph(str(key)), Paragraph(str(value))])
        row = row + 1
        data.append([Paragraph(str('****************************')), Paragraph(str('****************************'))])
        # data = [[],
        #         ['Enabled/Disabled Status', 'Compliance Status']]

    table_pdf = Table(data, (7 * cm, 7 * cm))  # , (8 * cm, 3 * cm, 3 * cm, 4 * cm)

    style = TableStyle([
        ('BACKGROUND', (0, 0), (5, 0), colors.black),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),

        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),

        ('FONTNAME', (0, 0), (-1, 0), 'Courier-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 14),

        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),

        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
    ])
    table_pdf.setStyle(style)

    # 2) Alternate backgroud color
    rowNumb = len(data)
    for i in range(1, rowNumb):
        if i % 2 == 0:
            bc = colors.burlywood
        else:
            bc = colors.beige

        ts = TableStyle(
            [('BACKGROUND', (0, i), (-1, i), bc)]  # ('ALIGN', (0, 0), (-1, -1), 'CENTER')
        )
        table_pdf.setStyle(ts)

    # 3) Add borders
    ts = TableStyle(
        [
            ('BOX', (0, 0), (-1, -1), 2, colors.black),
            # ('ALIGN', (0, 0), (-1, -1), 'CENTER'),  by hamza

            ('LINEBEFORE', (2, 1), (2, -1), 2, colors.red),
            ('LINEABOVE', (0, 2), (-1, 2), 2, colors.green),

            ('GRID', (0, 1), (-1, -1), 2, colors.black),
        ]
    )
    table_pdf.setStyle(ts)
    ip_range.append(KeepTogether(table_pdf))
    ip_range.append(KeepTogether(Spacer(1, 0.5 * inch)))

def gen_pdf(name):
    pdf_report.add_header()
    name = name + '.pdf'
    # self.NIST_report_result = True
    directory = os.curdir
    if not os.path.exists(directory):
        os.makedirs(directory)
    filepath = os.path.join(directory, name)

    pdf_report.pdf_elements.extend(ip_range)
    pdf_report.make_Report(filepath)





