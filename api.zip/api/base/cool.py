import streamlit as st
import requests
import json

url = "https://api.pawan.krd/v1/chat/completions"
headers = {
    'Authorization': 'Bearer pk-xyedLXMeUcocSUIiMDiaZtVyQtjtKBSoOXeazXqjnaWEHYQi',
    'Content-Type': 'application/json'
}


def get_response(messages):
    payload = json.dumps({
        "model": "gpt-3.5-turbo",
        "messages": messages
    })
    response = requests.request("POST", url, headers=headers, data=payload)
    messages.append(response.json()['choices'][0]['message'])
    return response.json()['choices'][0]['message']['content']


def main():
    st.title("Chat Assistant")

    # Initialize messages
    messages = [
        {
            "role": "system",
            "content": "You are a helpful assistant."
        },
        {
            "role": "user",
            "content": "Please always give responses in markdown."
        }
    ]

    # Display messages and user input
    for index, message in enumerate(messages):
        if message['role'] == 'user':
            st.text_input("You:", message['content'])
        else:
            st.text_area(f"Assistant {index}:", message['content'], value="", height=100, key=index)

    if st.button("Send"):
        user_input = st.text_input("You:")
        messages.append({"role": "user", "content": user_input})

        # Get response from the API
        assistant_response = get_response(messages)
        messages.append({"role": "assistant", "content": assistant_response})

        # Display assistant's response
        st.text_area(f"Assistant {len(messages) - 1}:", assistant_response, value="", height=100, key=len(messages))

    # Store the state of the messages
    st.session_state.messages = messages


if __name__ == "__main__":
    main()
