# start here
from reportlab.lib import colors
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.barcharts import HorizontalBarChart
from reportlab.platypus.flowables import KeepTogether
from reportlab.lib.colors import blue, red, green, yellow, orange
from reportlab.platypus import Paragraph, PageBreak, Spacer
from reportlab.platypus import SimpleDocTemplate, Image, Table
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.enums import TA_LEFT, TA_CENTER
import string
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import blue, cyan, red, green, fidlightblue
from reportlab.graphics.shapes import _DrawingEditorMixin
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.validators import Auto
from reportlab.graphics.charts.legends import Legend
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.shapes import Drawing
from reportlab.platypus import Paragraph
# add style
from reportlab.platypus import TableStyle
from reportlab.lib import colors
from reportlab.graphics.charts.legends import Legend
from reportlab.graphics.charts.piecharts import Pie
from reportlab.pdfbase.pdfmetrics import stringWidth, EmbeddedType1Face, registerTypeFace, Font, registerFont
from reportlab.graphics.shapes import Drawing, _DrawingEditorMixin
from reportlab.lib.colors import Color, PCMYKColor, white
# from reportlab.lib.colors import Color, PCMYKColor
# import matplotlib.pyplot as plt


# import matplotlib.pyplot as plt
# end here
class FooterCanvas(canvas.Canvas):

    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self.pages = []
        # self.space = []
        # self.NameK = Paragraph("<br>  </br>")

    def showPage(self):
        self.pages.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        page_count = len(self.pages)
        for page in self.pages:
            self.__dict__.update(page)
            self.draw_canvas(page_count)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_canvas(self, page_count):
        # self.space.append([Spacer(1, 0.5 * cm)])
        # name = " fffffffff "
        page = "NATIONAL CYBER SECURITY AUDITING AND EVALUATION LAB (NCSAEL)"
        email = "csael-nust@mcs.edu.pk                                                                         "
        phone = "+92-51-8731584-5"
        x = 128
        self.saveState()
        # self.NameK.append(Spacer(1, 0.5 * cm))
        # self.drawString(80, 160, self.NameK)
        # self.setStrokeColorRGB(0, 0, 0)
        # self.setLineWidth(2.5)
        # self.line.append(Spacer(1, 0.5 * cm))

        self.setStrokeColorRGB(0, 0, 0)
        self.setLineWidth(0.5)
        self.line(66, 70, LETTER[0] - 66, 70)
        self.setFont('Times-Roman', 12)
        # self.drawString(Spacer(1, 0.5 * cm), 800, page)
        # self.drawString(80, 65, name)
        self.drawString(90, 57, page)
        self.drawString(240, 42, email)
        self.drawString(250, 27, phone)

        # Header
        self.drawString(90, 800, page)
        self.line(66, 785, LETTER[0] - 66, 785)
        self.restoreState()


class Drawing_sign_unsigned_software_graph(_DrawingEditorMixin, Drawing):
    '''
           A Pie Chart
           ===========

           This is a simple pie chart that contains a basic legend.
       '''

    def __init__(self, signed_software, un_signed_software, width=400, height=200, *args, **kw):
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, Pie(), name=None, validate=None, desc=None)

        # Set the size and location of the chart
        self.contents[0].width = 150
        self.contents[0].height = 150
        self.contents[0].y = 0
        self.contents[0].x = 130  # 140

        # Fill in the chart with sample data and labels
        signed_software_percentage = (signed_software / (signed_software + un_signed_software)) * 100
        un_signed_software_percentage = (un_signed_software / (signed_software + un_signed_software)) * 100

        self.contents[0].data = [signed_software_percentage, un_signed_software_percentage]
        self.contents[0].labels = ['{:.2f}%'.format(signed_software_percentage),
                                   '{:.2f}%'.format(un_signed_software_percentage)]

        # Make the slices pop out and add a border to the slices  {}%.2f,   {:.2f}  ,  {}%
        self.contents[0].slices.popout = 3
        self.contents[0].slices.strokeWidth = 1

        # Set the font size and position the label
        self.contents[0].slices.fontSize = 14
        self.contents[0].slices.labelRadius = 1.25

        # Turn off simple labels so we can use customized labels
        self.contents[0].simpleLabels = 0
        # Define a simple pointer for all labels
        self.contents[0].slices.label_simple_pointer = 1
        self.contents[0].slices[0].fillColor = green
        self.contents[0].slices[0].fontColor = green
        self.contents[0].slices[1].fillColor = red
        self.contents[0].slices[1].fontColor = red
        # self.contents[0].slices[2].fillColor = green
        # self.contents[0].slices[2].fontColor = green
        self._add(self, Legend(), name='legend', validate=None, desc=None)
        self.legend.columnMaximum = 99
        self.legend.alignment = 'right'
        self.legend.dx = 8
        self.legend.dy = 8
        self.legend.dxTextSpace = 5
        self.legend.deltay = 10
        self.legend.strokeWidth = 0
        self.legend.subCols[0].minWidth = 75
        self.legend.subCols[0].align = 'left'
        self.legend.subCols[1].minWidth = 25
        self.legend.subCols[1].align = 'right'
        self.legend.boxAnchor = 'c'
        self.legend.y = 100
        self.legend.colorNamePairs = [(PCMYKColor(0, 100, 100, 0, alpha=100),
                                       ('Unsigned Software', '{:.2f}%'.format(un_signed_software_percentage))),
                                      (PCMYKColor(100, 0, 100, 0, alpha=100),
                                       ('Signed Software', '{:.2f}%'.format(signed_software_percentage)))]
        # self.width = 400
        self.legend.x = 350


class Drawing_sign_unsigned_drivers_graph(_DrawingEditorMixin, Drawing):

    def __init__(self, signed_drivers, un_signed_drivers, width=400, height=200, *args, **kw):
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, Pie(), name=None, validate=None, desc=None)

        # Set the size and location of the chart
        self.contents[0].width = 150
        self.contents[0].height = 150
        self.contents[0].y = 0
        self.contents[0].x = 130  # 140

        # Fill in the chart with sample data and labels
        signed_drivers_percentage = (signed_drivers / (signed_drivers + un_signed_drivers)) * 100
        un_signed_drivers_percentage = (un_signed_drivers / (signed_drivers + un_signed_drivers)) * 100

        self.contents[0].data = [signed_drivers_percentage, un_signed_drivers_percentage]
        self.contents[0].labels = ['{:.2f}%'.format(signed_drivers_percentage),
                                   '{:.2f}%'.format(un_signed_drivers_percentage)]

        # Make the slices pop out and add a border to the slices  {}%.2f,   {:.2f}  ,  {}%
        self.contents[0].slices.popout = 3
        self.contents[0].slices.strokeWidth = 1

        # Set the font size and position the label
        self.contents[0].slices.fontSize = 14
        self.contents[0].slices.labelRadius = 1.25

        # Turn off simple labels so we can use customized labels
        self.contents[0].simpleLabels = 0
        # Define a simple pointer for all labels
        self.contents[0].slices.label_simple_pointer = 1
        self.contents[0].slices[0].fillColor = green
        self.contents[0].slices[0].fontColor = green
        self.contents[0].slices[1].fillColor = red
        self.contents[0].slices[1].fontColor = red
        # self.contents[0].slices[2].fillColor = green
        # self.contents[0].slices[2].fontColor = green
        self._add(self, Legend(), name='legend', validate=None, desc=None)
        self.legend.columnMaximum = 99
        self.legend.alignment = 'right'
        self.legend.dx = 8
        self.legend.dy = 8
        self.legend.dxTextSpace = 5
        self.legend.deltay = 10
        self.legend.strokeWidth = 0
        self.legend.subCols[0].minWidth = 75
        self.legend.subCols[0].align = 'left'
        self.legend.subCols[1].minWidth = 25
        self.legend.subCols[1].align = 'right'
        self.legend.boxAnchor = 'c'
        self.legend.y = 100
        self.legend.colorNamePairs = [(PCMYKColor(0, 100, 100, 0, alpha=100),
                                       ('Unsigned Drivers', '{:.2f}%'.format(un_signed_drivers_percentage))),
                                      (PCMYKColor(100, 0, 100, 0, alpha=100),
                                       ('Signed Drivers', '{:.2f}%'.format(signed_drivers_percentage)))]
        # self.width = 400
        self.legend.x = 350


class Drawing_counter_measures_firewal_rules_graph(_DrawingEditorMixin, Drawing):
    '''
           A Pie Chart
           ===========

           This is a simple pie chart that contains a basic legend.
       '''

    def __init__(self, in_bound_rules, out_bound_rules, width=400, height=200, *args, **kw): # Constructor
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, Pie(), name=None, validate=None, desc=None)

        # Set the size and location of the chart
        self.contents[0].width = 150 # 150
        self.contents[0].height = 150 # 150
        self.contents[0].y = 0
        self.contents[0].x = 130  # 140

        # Fill in the chart with sample data and labels
        in_bound_rules_percentage = (in_bound_rules / (in_bound_rules + out_bound_rules)) * 100
        out_bound_rules_percentage = (out_bound_rules / (in_bound_rules + out_bound_rules)) * 100

        self.contents[0].data = [in_bound_rules_percentage, out_bound_rules_percentage]
        self.contents[0].labels = ['{:.2f}%'.format(in_bound_rules_percentage),
                                   '{:.2f}%'.format(out_bound_rules_percentage)]

        # Make the slices pop out and add a border to the slices  {}%.2f,   {:.2f}  ,  {}%
        self.contents[0].slices.popout = 3
        self.contents[0].slices.strokeWidth = 1

        # Set the font size and position the label
        self.contents[0].slices.fontSize = 14
        self.contents[0].slices.labelRadius = 1.25

        # Turn off simple labels so we can use customized labels
        self.contents[0].simpleLabels = 0
        # Define a simple pointer for all labels
        self.contents[0].slices.label_simple_pointer = 1
        self.contents[0].slices[0].fillColor = green
        self.contents[0].slices[0].fontColor = green
        self.contents[0].slices[1].fillColor = red
        self.contents[0].slices[1].fontColor = red
        # self.contents[0].slices[2].fillColor = green
        # self.contents[0].slices[2].fontColor = green
        self._add(self, Legend(), name='legend', validate=None, desc=None)
        self.legend.columnMaximum = 99
        self.legend.alignment = 'right'
        self.legend.dx = 8
        self.legend.dy = 8
        self.legend.dxTextSpace = 5
        self.legend.deltay = 10
        self.legend.strokeWidth = 0
        self.legend.subCols[0].minWidth = 75
        self.legend.subCols[0].align = 'left'
        self.legend.subCols[1].minWidth = 25
        self.legend.subCols[1].align = 'right'
        self.legend.boxAnchor = 'c'
        self.legend.y = 100
        self.legend.colorNamePairs = [
            (PCMYKColor(0, 100, 100, 0, alpha=100), ('In Bound Rules', '{:.2f}%'.format(out_bound_rules_percentage))),
            (PCMYKColor(100, 0, 100, 0, alpha=100), ('Out Bound Rules', '{:.2f}%'.format(in_bound_rules_percentage)))]
        # self.width = 400
        self.legend.x = 350




class Drawing_accounts_data_graph(_DrawingEditorMixin, Drawing):
    def __init__(self, admin, guest, System_Managed_Accounts_Group, width=400, height=200, *args, **kw):
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, Pie(), name=None, validate=None, desc=None)

        # Set the size and location of the chart
        self.contents[0].width = 137 # 137
        self.contents[0].height = 137 # 137
        self.contents[0].y = 0
        self.contents[0].x = 140  # 140

        # Fill in the chart with sample data and labels
        admin_percent = (admin / (admin + guest + System_Managed_Accounts_Group)) * 100
        guest_percent = (guest / (admin + guest + System_Managed_Accounts_Group)) * 100
        System_Managed_Accounts_Group_percent = (System_Managed_Accounts_Group / (
                    admin + guest + System_Managed_Accounts_Group)) * 100

        self.contents[0].data = [admin_percent, guest_percent, System_Managed_Accounts_Group_percent]
        self.contents[0].labels = ['{:.2f}%'.format(admin_percent),
                                   '{:.2f}%'.format(System_Managed_Accounts_Group_percent),
                                   '{:.2f}%'.format(guest_percent)]

        # Make the slices pop out and add a border to the slices  {}%.2f,   {:.2f}  ,  {}%
        self.contents[0].slices.popout = 3
        self.contents[0].slices.strokeWidth = 1

        # Set the font size and position the label
        self.contents[0].slices.fontSize = 14
        self.contents[0].slices.labelRadius = 1.25

        # Turn off simple labels so we can use customized labels
        self.contents[0].simpleLabels = 0
        # Define a simple pointer for all labels
        self.contents[0].slices.label_simple_pointer = 1
        self.contents[0].slices[0].fillColor = green
        self.contents[0].slices[0].fontColor = green
        self.contents[0].slices[2].fillColor = yellow
        self.contents[0].slices[2].fontColor = yellow
        self.contents[0].slices[1].fillColor = red
        self.contents[0].slices[1].fontColor = red
        # self.contents[0].slices[2].fillColor = green
        # self.contents[0].slices[2].fontColor = green
        self._add(self, Legend(), name='legend', validate=None, desc=None)
        self.legend.columnMaximum = 99
        self.legend.alignment = 'right'
        self.legend.dx = 8
        self.legend.dy = 8
        self.legend.dxTextSpace = 5
        self.legend.deltay = 14
        self.legend.strokeWidth = 0
        self.legend.subCols[0].minWidth = 75
        self.legend.subCols[0].align = 'left'
        self.legend.subCols[1].minWidth = 25
        self.legend.subCols[1].align = 'right'
        self.legend.boxAnchor = 'c'
        self.legend.y = 100
        self.legend.colorNamePairs = [
            (PCMYKColor(100, 0, 100, 0, alpha=100), ('Administrators', '{:.2f}%'.format(admin_percent))),
            (PCMYKColor(0, 0, 100, 0, alpha=100), ('Guests', '{:.2f}%'.format(System_Managed_Accounts_Group_percent))),
            (PCMYKColor(0, 100, 100, 0, alpha=100), ('System Managed Accounts', '{:.2f}%'.format(guest_percent)))]

        # self.width = 400
        self.legend.x = 350


def Drawing_combine_graph(self, in_bound_rules, out_bound_rules, admin, guest, System_Managed_Accounts_Group,
                          signed_software, un_signed_software, signed_drivers, un_signed_drivers):
    from reportlab.lib import colors
    from reportlab.graphics.shapes import Drawing
    from reportlab.graphics.charts.barcharts import HorizontalBarChart, VerticalBarChart

    # drawing = Drawing(300, 100) # change
    drawing = Drawing(100, 250)
    in_bound_rules_percentage = (in_bound_rules / (
            in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100
    out_bound_rules_percentage = (out_bound_rules / (
            in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100

    # Account Portion

    # Fill in the chart with sample data and labels
    admin_percent = (admin / (
            in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100
    guest_percent = (guest / (
            in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100
    System_Managed_Accounts_Group_percent = (System_Managed_Accounts_Group / (
            in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100

    # Software Portion
    signed_software_percentage = (signed_software / (
            in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100
    un_signed_software_percentage = (un_signed_software / (
            in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100

    # Hardware Portion

    signed_drivers_percentage = (signed_drivers / (
            in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100
    un_signed_drivers_percentage = (un_signed_drivers / (
            in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100

    data = [
        (in_bound_rules_percentage, out_bound_rules_percentage,
         admin_percent, guest_percent, System_Managed_Accounts_Group_percent,
         signed_software_percentage, un_signed_software_percentage,
         signed_drivers_percentage, un_signed_drivers_percentage)
    ]
    # data = [
    #     (secured + insecured, insecured)
    # ]

    names = ['Administrators', 'Guests', 'System Managed Accounts', 'In Bound Rules',
             'Out Bound Rules', 'Unsigned Software', 'Signed Software',
             'Unsigned Drivers', 'Signed Drivers']

    bc = HorizontalBarChart()
    # bc = VerticalBarChart()
    bc.x = 115  # change from 90
    bc.y = 80  # Change from 50
    bc.height = 150  # change
    bc.width = 300  # change
    bc.data = data
    bc.strokeColor = colors.white
    bc.valueAxis.valueMin = 0
    bc.valueAxis.valueMax = 50
    # if secured >= insecured:
    #     bc.valueAxis.valueMax = 10  # secured + 1
    # else:
    #     bc.valueAxis.valueMax = 10  # insecured + 1
    bc.valueAxis.valueStep = 5
    bc.categoryAxis.labels.boxAnchor = 'ne'
    bc.categoryAxis.labels.dx = -10
    bc.categoryAxis.labels.fontName = 'Helvetica'
    bc.categoryAxis.categoryNames = names
    bc.bars[(0, 0)].fillColor = colors.blue
    bc.bars[(0, 1)].fillColor = colors.red
    bc.bars[(0, 2)].fillColor = colors.orange
    bc.bars[(0, 3)].fillColor = colors.brown
    bc.bars[(0, 4)].fillColor = colors.cornflower
    bc.bars[(0, 5)].fillColor = colors.yellow
    bc.bars[(0, 6)].fillColor = colors.dimgrey
    bc.bars[(0, 7)].fillColor = colors.orange
    bc.bars[(0, 8)].fillColor = colors.bisque
    # bc.bars[(0, 3)].fillColor = colors.blue
    drawing.add(bc)
    return drawing



class pdfReport:
    def set_path(self, filename):
        self.filename = "reports" + r"/" + filename

    def __init__(self, filename):
        self.filename = "reports" + r"/" + filename

    def add_legend(self, draw_obj, chart, data):
        legend = Legend()
        legend.alignment = 'right'
        legend.x = 10
        legend.y = 70
        legend.colorNamePairs = [(Auto(obj=chart), ('Critical', '56.0%')), (Auto(obj=chart), ('Medium', '56.0%')),
                                 (Auto(obj=chart), ('Low', '56.0%'))]
        # legend.colorNamePairs = ["Red", "Blue"]

        draw_obj.add(legend)

    def pie_chart_with_legend(self, Critical, Medium, Low):
        # data = list(range(15, 105, 15))
        # print(data)
        data = [Critical, Medium, Low]
        drawing = Drawing(width=400, height=300)
        # my_title = String(150, 40, 'Secured/Insecured Ratio', fontName="Helvetica-Bold", fontSize=12)
        pie = Pie()
        #    pie.xradius = 70
        #    pie.yradius = 70
        pie.sideLabels = True
        pie.x = 140
        pie.y = 65
        pie.height = 200
        pie.width = 200
        pie.slices.popout = 3
        pie.slices.labelRadius = 0.8
        pie.slices[0].fillColor = red
        pie.slices[1].fillColor = orange
        pie.slices[2].fillColor = green

        pie.data = data
        pie.labels = ['Critical', 'Medium', 'Low']
        pie.slices.strokeWidth = 1
        # drawing.add(my_title)
        drawing.add(pie)

        self.add_legend(drawing, pie, data)

        return drawing

    # start here graph

    def add_legend(self, draw_obj, chart, data):
        legend = Legend()
        legend.alignment = 'right'
        legend.x = 10
        legend.y = 20
        legend.colorNamePairs = Auto(obj=chart)
        # legend.colorNamePairs = ["Red", "Blue"]

        draw_obj.add(legend)


    #
    # end here graph
    # Start here

    def generate_pdf(self):
        doc = SimpleDocTemplate(self.filename)

        url = 'Operating System Compliance Toolkit (OSCT)'
        date = "28/12/2020"
        time = "12:5.14"

        day = "Friday"
        print("+Search+code is here work pieChartPDF4...")

        document_pdf = []
        self.spaceadd = []
        # styles = getSampleStyleSheet()

        # region FRONT PAGE
        filename_nust = Image('nust.png', 5 * cm, 5 * cm)
        # elements.append(filename_nust)

        filename_ncsael = Image('ncsael.png', 5 * cm, 5 * cm)
        # elements.append(filename_ncsael)

        filename_mcs = Image('mcs.jpg', 5 * cm, 5 * cm)
        # elements.append(filename_mcs)
        tbl_data = [
            [filename_nust, filename_ncsael, filename_mcs]
        ]
        tbl = Table(tbl_data, (5 * cm, 5 * cm, 5 * cm))
        document_pdf.append(tbl)

        style_center = ParagraphStyle(name='ncsael', fontSize=14, color='white',
                                      leftIndent=0, alignment=TA_CENTER)
        style_center_heading = ParagraphStyle(name='ncsael3', fontName="Helvetica", fontSize=20, color='white',
                                              leftIndent=0, alignment=TA_CENTER)
        # giving alias to the stylesheet
        ptext = Paragraph('<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />',
                          style_center)
        document_pdf.append(ptext)
        ptext = Paragraph('<br /><b>{}</b><br />'.format(url), style_center_heading)
        document_pdf.append(ptext)
        ptext = Paragraph('<br /><br />{}<br />'.format(date), style_center)
        document_pdf.append(ptext)
        ptext = Paragraph('<br />{}<br /><br />'.format(time), style_center)
        document_pdf.append(ptext)
        # day here for test
        ptext = Paragraph('<br />{}<br /><br />'.format(day), style_center)
        document_pdf.append(ptext)

        # page break
        document_pdf.append(PageBreak())

        chart = self.pie_chart_with_legend(1, 2, 3)

        document_pdf.append(chart)

        # page break 3
        document_pdf.append(PageBreak())

        # List of Lists
        data = [
            ['User Accounts'],
            ['Name', 'Account Type', 'Local', 'Account Domain', 'Account SID', 'Account SID Type'],
            ['Free Domain', 'Free Domain', 'Free Domain', 'Free Domain', '', ''],
            ['2GB DDR2', '20GB Disc Space', 'Unlimited Email', 'Unlimited Email', '', '']
        ]

        table = Table(data)

        style = TableStyle([
            ('BACKGROUND', (0, 0), (5, 0), colors.black),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),

            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),

            ('FONTNAME', (0, 0), (-1, 0), 'Courier-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 14),

            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),

            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ])
        table.setStyle(style)

        # 2) Alternate backgroud color
        rowNumb = len(data)
        for i in range(1, rowNumb):
            if i % 2 == 0:
                bc = colors.burlywood
            else:
                bc = colors.beige

            ts = TableStyle(
                [('BACKGROUND', (0, i), (-1, i), bc)]
            )
            table.setStyle(ts)

        # 3) Add borders
        ts = TableStyle(
            [
                ('BOX', (0, 0), (-1, -1), 2, colors.black),

                ('LINEBEFORE', (2, 1), (2, -1), 2, colors.red),
                ('LINEABOVE', (0, 2), (-1, 2), 2, colors.green),

                ('GRID', (0, 1), (-1, -1), 2, colors.black),
            ]
        )
        table.setStyle(ts)

        document_pdf.append(table)

        # pdfReport.build(table)

        # chart code here
        # chart = self.pie_chart_with_legend(1, 2, 3)

        # document_pdf.append(chart)
        # chart code end here

        doc.multiBuild(document_pdf, canvasmaker=FooterCanvas)



'''class Drawing_combine(_DrawingEditorMixin, Drawing):
    def __init__(self, admin, guest, System_Managed_Accounts_Group, width=400, height=200, *args, **kw):
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, Pie(), name=None, validate=None, desc=None)

        # Set the size and location of the chart
        self.contents[0].width = 137
        self.contents[0].height = 137
        self.contents[0].y = 0
        self.contents[0].x = 130 # 140

        # Fill in the chart with sample data and labels
        admin_percent = (admin/(admin+guest + System_Managed_Accounts_Group)) * 100
        guest_percent = (guest/(admin+guest + System_Managed_Accounts_Group)) * 100
        System_Managed_Accounts_Group_percent = (System_Managed_Accounts_Group/(admin+guest + System_Managed_Accounts_Group)) * 100

        self.contents[0].data = [admin_percent, guest_percent, System_Managed_Accounts_Group_percent]
        self.contents[0].labels = ['{:.2f}%'.format(admin_percent),'{:.2f}%'.format(System_Managed_Accounts_Group_percent),  '{:.2f}%'.format(guest_percent)]


        # Make the slices pop out and add a border to the slices  {}%.2f,   {:.2f}  ,  {}%
        self.contents[0].slices.popout = 3
        self.contents[0].slices.strokeWidth = 1


        # Set the font size and position the label
        self.contents[0].slices.fontSize = 14
        self.contents[0].slices.labelRadius = 1.25

        # Turn off simple labels so we can use customized labels
        self.contents[0].simpleLabels = 0
        # Define a simple pointer for all labels
        self.contents[0].slices.label_simple_pointer = 1
        self.contents[0].slices[0].fillColor = green
        self.contents[0].slices[0].fontColor = green
        self.contents[0].slices[2].fillColor = yellow
        self.contents[0].slices[2].fontColor = yellow
        self.contents[0].slices[1].fillColor = red
        self.contents[0].slices[1].fontColor = red
        # self.contents[0].slices[2].fillColor = green
        # self.contents[0].slices[2].fontColor = green
        self._add(self, Legend(), name='legend', validate=None, desc=None)
        self.legend.columnMaximum = 99
        self.legend.alignment = 'right'
        self.legend.dx = 8
        self.legend.dy = 8
        self.legend.dxTextSpace = 5
        self.legend.deltay = 14
        self.legend.strokeWidth = 0
        self.legend.subCols[0].minWidth = 75
        self.legend.subCols[0].align = 'left'
        self.legend.subCols[1].minWidth = 25
        self.legend.subCols[1].align = 'right'
        self.legend.boxAnchor = 'c'
        self.legend.y = 100
        self.legend.colorNamePairs = [(PCMYKColor(100, 0, 100, 0, alpha=100), ('Administrators', '{:.2f}%'.format(admin_percent))),
                                      (PCMYKColor(0, 0, 100, 0, alpha=100), ('Guests', '{:.2f}%'.format(System_Managed_Accounts_Group_percent))),
                                      (PCMYKColor(0, 100, 100, 0, alpha=100), ('System Managed Accounts', '{:.2f}%'.format(guest_percent)))]

        # self.width = 400
        self.legend.x = 350

        '''

''' class Drawing_combine_graph(_DrawingEditorMixin, Drawing):
    def __init__(self, in_bound_rules, out_bound_rules, admin, guest, System_Managed_Accounts_Group, signed_software, un_signed_software, signed_drivers, un_signed_drivers, width=400, height=200, *args, **kw):
        Drawing.__init__(self, width, height, *args, **kw)
        self._add(self, Pie(), name=None, validate=None, desc=None)

        # Set the size and location of the chart
        self.contents[0].width = 137
        self.contents[0].height = 137
        self.contents[0].y = 0
        self.contents[0].x = 130 # 140

        # Firewall Portion

        in_bound_rules_percentage = (in_bound_rules / (in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100
        out_bound_rules_percentage = (out_bound_rules / (in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100

        # self.contents[0].data = [in_bound_rules_percentage, out_bound_rules_percentage]
        # self.contents[0].labels = ['{:.2f}%'.format(in_bound_rules_percentage),
        #                            '{:.2f}%'.format(out_bound_rules_percentage)]

        # Account Portion

        # Fill in the chart with sample data and labels
        admin_percent = (admin/(in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100
        guest_percent = (guest/(in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100
        System_Managed_Accounts_Group_percent = (System_Managed_Accounts_Group/(in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100

        # self.contents[0].data = [admin_percent, guest_percent, System_Managed_Accounts_Group_percent]
        # self.contents[0].labels = ['{:.2f}%'.format(admin_percent),'{:.2f}%'.format(System_Managed_Accounts_Group_percent),  '{:.2f}%'.format(guest_percent)]


        # Software Portion
        signed_software_percentage = (signed_software / (in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100
        un_signed_software_percentage = (un_signed_software / (in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100

        # self.contents[0].data = [signed_software_percentage, un_signed_software_percentage]
        # self.contents[0].labels = ['{:.2f}%'.format(signed_software_percentage),
        #                            '{:.2f}%'.format(un_signed_software_percentage)]

        #Hardware Portion

        signed_drivers_percentage = (signed_drivers / (in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100
        un_signed_drivers_percentage = (un_signed_drivers / (in_bound_rules + out_bound_rules + admin + guest + System_Managed_Accounts_Group + signed_software + un_signed_software + signed_drivers + un_signed_drivers)) * 100

        self.contents[0].data = [in_bound_rules_percentage, out_bound_rules_percentage,
                                 admin_percent, guest_percent, System_Managed_Accounts_Group_percent,
                                 signed_software_percentage, un_signed_software_percentage,
                                 signed_drivers_percentage,un_signed_drivers_percentage,
                                 ]
        self.contents[0].labels = ['{:.2f}%'.format(in_bound_rules_percentage),
                                   '{:.2f}%'.format(out_bound_rules_percentage),
                                   '{:.2f}%'.format(admin_percent),
                                   '{:.2f}%'.format(System_Managed_Accounts_Group_percent),
                                   '{:.2f}%'.format(guest_percent),
                                   '{:.2f}%'.format(signed_software_percentage),
                                   '{:.2f}%'.format(un_signed_software_percentage),
                                   '{:.2f}%'.format(signed_drivers_percentage),
                                   '{:.2f}%'.format(un_signed_drivers_percentage)
                                   ]




        # Make the slices pop out and add a border to the slices  {}%.2f,   {:.2f}  ,  {}%
        self.contents[0].slices.popout = 3 # change to 3
        self.contents[0].slices.strokeWidth = 1


        # Set the font size and position the label
        self.contents[0].slices.fontSize = 14
        self.contents[0].slices.labelRadius = 1.25

        # Turn off simple labels so we can use customized labels
        self.contents[0].simpleLabels = 0
        # Define a simple pointer for all labels
        self.contents[0].slices.label_simple_pointer = 1
        self.contents[0].slices[0].fillColor = orange
        self.contents[0].slices[0].fontColor = orange
        self.contents[0].slices[1].fillColor = yellow
        self.contents[0].slices[1].fontColor = yellow
        self.contents[0].slices[2].fillColor = red
        self.contents[0].slices[2].fontColor = red
        self.contents[0].slices[3].fillColor = green
        self.contents[0].slices[3].fontColor = green
        self.contents[0].slices[4].fillColor = blue
        self.contents[0].slices[4].fontColor = blue
        self.contents[0].slices[5].fillColor = orange
        self.contents[0].slices[5].fontColor = orange
        self.contents[0].slices[6].fillColor = yellow
        self.contents[0].slices[6].fontColor = yellow
        self.contents[0].slices[7].fillColor = red
        self.contents[0].slices[7].fontColor = red
        self.contents[0].slices[8].fillColor = blue
        self.contents[0].slices[8].fontColor = blue
        # self.contents[0].slices[2].fillColor = green
        # self.contents[0].slices[2].fontColor = green
        self._add(self, Legend(), name='legend', validate=None, desc=None)
        self.legend.columnMaximum = 99
        self.legend.alignment = 'right'
        self.legend.dx = 8
        self.legend.dy = 8
        self.legend.dxTextSpace = 5
        self.legend.deltay = 14
        self.legend.strokeWidth = 0
        self.legend.subCols[0].minWidth = 75
        self.legend.subCols[0].align = 'left'
        self.legend.subCols[1].minWidth = 25
        self.legend.subCols[1].align = 'right'
        self.legend.boxAnchor = 'c'
        self.legend.y = 100
        self.legend.colorNamePairs = [(PCMYKColor(100, 0, 100, 0, alpha=100), ('Administrators', '{:.2f}%'.format(admin_percent))),
                                      (PCMYKColor(0, 0, 100, 0, alpha=100), ('Guests', '{:.2f}%'.format(System_Managed_Accounts_Group_percent))),
                                      (PCMYKColor(0, 100, 100, 0, alpha=100), ('System Managed Accounts', '{:.2f}%'.format(guest_percent))),
                                      (PCMYKColor(0, 100, 100, 0, alpha=100), ('In Bound Rules', '{:.2f}%'.format(out_bound_rules_percentage))),
                                      (PCMYKColor(100, 0, 100, 0, alpha=100), ('Out Bound Rules', '{:.2f}%'.format(in_bound_rules_percentage))),
                                      (PCMYKColor(0, 100, 100, 0, alpha=100),('Unsigned Software', '{:.2f}%'.format(un_signed_software_percentage))),
                                      (PCMYKColor(100, 0, 100, 0, alpha=100),('Signed Software', '{:.2f}%'.format(signed_software_percentage))),
                                      (PCMYKColor(0, 100, 100, 0, alpha=100),('Unsigned Drivers', '{:.2f}%'.format(un_signed_drivers_percentage))),
                                      (PCMYKColor(100, 0, 100, 0, alpha=100),('Signed Drivers', '{:.2f}%'.format(signed_drivers_percentage)))
                                      ]



        # self.width = 400
        self.legend.x = 350 '''

'''def pie_chart_with_legend(self, secured, insecured):
    data = list(range(15, 105, 15))
    # print(data)
    data = [secured, insecured]
    drawing = Drawing(width=400, height=200)
    my_title = string(150, 40, 'Secured/Insecured Ratio', fontName="Helvetica-Bold", fontSize=12) # Edited Here
    pie = Pie()

    pie.xradius = 100
    pie.yradius = 100

    pie.sideLabels =False
    pie.x = 100
    pie.y = 65
    pie.data = data
    pie.labels = ['Secured', 'Insecured']
    pie.slices.strokeWidth = 1
    drawing.add(my_title)
    drawing.add(pie)

    self.add_legend(drawing, pie, data)

    return drawing  '''

# A Pie Chart
# ===========
#
# This is a simple pie chart that contains a basic legend.
