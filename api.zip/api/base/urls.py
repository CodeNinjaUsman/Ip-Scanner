from django.urls import path
from . import views
from django.contrib.auth import views as auth_views 

urlpatterns=[
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('results/<str:pk>/',views.result_gui),
    path('',views.home),
    path('search/',views.search),
    path('table/iprange',views.table),
    path('table/ip',views.table_ip),
    path('ip/<str:pk>',views.ip_detail),
    path('download/',views.download),
    path('download/ip',views.download_ip),
    path('download/ip_range',views.download_ip_range),
    path('download/ip_range/<str:pk>',views.download_ip_of_range),
    path('logout/', views.logout_user),
    path('report/<int:pk>', views.reportgen),
    # path('obtain_token/', views.ObtainToken.as_view()),
    # path('scan/info/', views.Info.as_view()),
    # path('scan/status/', views.Status.as_view()),
    # path('scan/start/', views.Start.as_view())
]
