from rest_framework import serializers
from .models import *


class IPSerializer(serializers.ModelSerializer):
    class Meta:
        model = IP
        fields = '__all__'


class IpRangeSerializer(serializers.ModelSerializer):
    class Meta:
        model = IpRange
        fields = '__all__'


class IDSerializer(serializers.Serializer):
    id = serializers.IntegerField()


class TokenSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=100)
    password = serializers.CharField(max_length=100)
