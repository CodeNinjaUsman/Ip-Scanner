from django.db import models
from django.db import models
from django.utils import timezone

class IpRange(models.Model):
    ip_range = models.CharField(max_length=25)
    external = models.IntegerField(default=0)
    created = models.PositiveSmallIntegerField(choices=[(i, i) for i in range(1, 8)], default=timezone.now().weekday() + 1)

    def __str__(self):
        return self.ip_range



class IP(models.Model):
    # Fields for IP model
    ip = models.CharField(max_length=50)
    country = models.CharField(max_length=100, null=True)
    https_status = models.CharField(max_length=10, null=True)
    cn = models.CharField(max_length=100, null=True)
    os = models.CharField(max_length=100, null=True)
    ports = models.JSONField(null=True)
    http_status = models.CharField(max_length=10, null=True)
    https_title = models.CharField(max_length=100, null=True)
    http_title = models.CharField(max_length=100, null=True)
    https_tech = models.JSONField(null=True)
    http_tech = models.JSONField(null=True)
    asn = models.CharField(max_length=100, null=True)
    org = models.CharField(max_length=100, null=True)
    latitude = models.FloatField(null=True)
    longitude = models.FloatField(null=True)
    ip_range_ref = models.ForeignKey(IpRange, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.ip
