from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus.flowables import KeepTogether
from reportlab.platypus import Paragraph, PageBreak, Spacer
from reportlab.platypus import SimpleDocTemplate, Image, Table
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import cm
from datetime import date, datetime
from .pieChartPDF4 import FooterCanvas
from datetime import date, datetime
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.rl_config import defaultPageSize
from reportlab.lib.units import inch
PAGE_HEIGHT= defaultPageSize[1]
PAGE_WIDTH= defaultPageSize[0]
styles = getSampleStyleSheet()
Title = "Hello world"
pageinfo = "platypus example"

class LandscapeMaker:
    pass


class pdfReport:
    def __init__(self):
        self.reportData = None
        self.category = None
        self.reportHead = None
        self.pdf_elements = []
        self.pdf_elements_check = []

    def add_header(self):
        filename_mcs = Image('images.jpg', 5 * cm, 5 * cm, hAlign="LEFT") # mcs-1.png
        filename_ncsael = Image('ncsael.png', 5 * cm, 5 * cm, hAlign="RIGHT") # 5 Cm Width and Height
        tbl_data = [
            [filename_mcs,  "                   ", filename_ncsael]
        ]
        tbl = Table(tbl_data, ( 5 * cm,  7 * cm,  5 * cm)) # 3.2
        self.pdf_elements.append(KeepTogether(tbl))


        url = 'IP Scanner'
        current_date = date.today().strftime("%d/%m/%Y")
        current_time = datetime.now().strftime("%H:%M:%S")
        style_center = ParagraphStyle(name='ncsael', fontSize=14, color='white',
                                      leftIndent=0, alignment=TA_CENTER)
        style_center_heading = ParagraphStyle(name='ncsael3', fontName="Helvetica", fontSize=20, color='white',
                                              leftIndent=0, alignment=TA_CENTER)
        # giving alias to the stylesheet
        ptext = Paragraph('<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />',
                          style_center)
        self.pdf_elements.append(ptext)
        ptext = Paragraph('<br /><b>{}</b><br />'.format(url), style_center_heading)
        self.pdf_elements.append(ptext)
        ptext = Paragraph('<br /><br />{}<br />'.format(current_date), style_center)
        self.pdf_elements.append(ptext)
        ptext = Paragraph('<br />{}<br /><br />'.format(current_time), style_center)
        self.pdf_elements.append(ptext)
        self.pdf_elements.append(PageBreak()) # First PageBreak()  Edited

    def append1(self, element):
        self.pdf_elements.append(KeepTogether(element))

    def make_Report(self, filename):

        self.doc = SimpleDocTemplate(filename) # A5 Does not suite with landscape

        self.pdf_elements_check = self.pdf_elements
        self.doc.multiBuild(self.pdf_elements, canvasmaker=FooterCanvas)
        self.pdf_elements = []


    def myFirstPage(canvas, doc):
        canvas.saveState()
        canvas.setFont('Times-Bold', 16)
        canvas.drawCentredString(PAGE_WIDTH / 2.0, PAGE_HEIGHT - 108, Title)
        canvas.setFont('Times-Roman', 9)
        canvas.drawString(inch, 0.75 * inch, "First Page / %s" % pageinfo)
        canvas.restoreState()

    def myLaterPages(canvas, doc):
        canvas.saveState()
        canvas.setFont('Times-Roman', 9)
        canvas.drawString(inch, 0.75 * inch, "Page %d %s" % (doc.page, pageinfo))
        canvas.restoreState()
