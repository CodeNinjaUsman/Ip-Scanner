import ssl
import socket
import requests
import threading
from bs4 import BeautifulSoup
import webtech
from cryptography import x509
import urllib
import ssl
import sys
import traceback
import ipaddress
import threading
import concurrent.futures
import requests
import webtech
import socket
import ssl
from bs4 import BeautifulSoup
from cryptography import x509
from cryptography.hazmat import backends
import webtech.utils
import time
import nmap

class Computate:
    def __init__(self, obj):
        self.cidr = obj.ip_range
        self.id = obj.id
        self.external = obj.external
        self.external_info = []
        self.wt = webtech.WebTech(options={'json': True})
        self.ips = self._get_ips_from_cidr()
        self.wordlist_path = "directory-list-2.3-medium.txt"
        self.timeout = 5
        self.dirs_lenght = 20
        self.status = "Not Started"
        self.info = []
        self.percentage = 0
        self.total_ips = len(self.ips)
        self.done_ips = 0
        self.increment = (1/self.total_ips)*100
        self.threads = []
        self.error = []
        self.ports=[80,443,22,21,3389,8080,3000,8000,8001,8002,8443,3001]

    def start(self, index):
        if self.done_ips == 255:
            print("Doing", self.ips[index], "Index:", index, "Percentage:", self.percentage, "%")
        try:
            cool = self.get_ip_info(self.ips[index])
            self.info.append(cool)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            file_name = exc_tb.tb_frame.f_code.co_filename
            line_number = exc_tb.tb_lineno
            self.error.append({"IP":self.ips[index],"Error":str(e),"Line":line_number,"File":file_name})

        self.done_ips += 1
        self.percentage += self.increment
        print("Done are:", self.done_ips, "Total:", self.total_ips)

    def process_ips(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=100) as executor:
            futures = []
            for index, _ in enumerate(self.ips):
                future = executor.submit(self.start, index)
                futures.append(future)

            # Wait for all futures to complete
            for future in concurrent.futures.as_completed(futures):
                pass

        self.status = "Done"

    def start_all(self):
        self.status = "Started"
        self.thread = threading.Thread(target=self.process_ips)
        self.thread.start()

    def get_open_ports(self, ip_address):
        open_ports = []
        nm = nmap.PortScanner()
        
        port_range = ','.join(str(port) for port in self.ports)
        nm.scan(ip_address, arguments=f'-p {port_range}')
        
        for port in self.ports:
            port_status = nm[ip_address]['tcp'][port]['state']
            port_service = nm[ip_address]['tcp'][port]['name']
            open_ports.append([port_service, port, port_status])
        
        return open_ports

    def get_os_of_ip(self, ip_address):
      try:
        nm = nmap.PortScanner()
        nm.scan(ip_address, arguments='-O')
        if 'osmatch' in nm[ip_address]:
            os_match = nm[ip_address]['osmatch'][0]
            return os_match['name']
        else:
            return "None"
      except:
        return "None"

    def get_ip_info(self, ip):
        ipapi_url = f"https://ipapi.co/{ip}/json/"

        https_url = "https://" + ip
        http_url = "http://" + ip

        response = requests.get(ipapi_url)
        geolocation_data = response.json()

        http_status = self.get_status_code(http_url)
        http_tech = self.get_technology_stack(http_url)
        http_title = self.get_page_title(http_url)

        https_status = self.get_status_code(https_url)
        https_tech = self.get_technology_stack(https_url)
        https_title = self.get_page_title(https_url)
        cn = self.get_cn_from_ssl(ip)
        latitude = geolocation_data.get('latitude')
        longitude = geolocation_data.get('longitude')
        asn = geolocation_data.get('asn')
        org = geolocation_data.get('org')
        country = geolocation_data.get('country_name')
        if latitude is None:
            latitude = 0.0
        if longitude is None:
            longitude = 0.0
        if asn is None:
            asn = "None"
        if org is None:
            org = "None"
        if country is None:
            country = "None"
        json = {
            'ip': ip,
            'os': self.get_os_of_ip(ip),
            'ports': self.get_open_ports(ip),
            'country': country,
            'https_status': https_status,
            'cn': cn,
            'http_status': http_status,
            'https_title': https_title,
            'http_title': http_title,
            'https_tech': https_tech,
            'http_tech': http_tech,
            'asn': asn,
            'org': org,
            'latitude': latitude,
            'longitude': longitude
        }
        json['ip_range_ref'] = self.id

        return json

    def get_cn_from_ssl(self, hostname):
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        try:
            with socket.create_connection((hostname, 443), timeout=self.timeout) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    pem_cert = ssl.get_server_certificate((hostname, 443))
                    x509_cert = x509.load_pem_x509_certificate(
                        pem_cert.encode('utf-8'), backends.default_backend())
                    cn = x509_cert.subject.get_attributes_for_oid(
                        x509.NameOID.COMMON_NAME)[0].value
                    return cn
        except socket.timeout:
            return "None"

    def get_status_code(self, url):
        try:
            headers = {
                "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 OPR/99.0.0.0"
            }
            response = requests.get(url, verify=False, timeout=self.timeout, headers=headers)
            status_code = response.status_code
            return status_code
        except requests.exceptions.Timeout:
            return "None"

    def get_page_title(self, url):
        try:
            headers = {
                "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 OPR/99.0.0.0"
            }
            response = requests.get(url, timeout=self.timeout, headers=headers)
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                title = soup.title.string
                return title
        except requests.exceptions.RequestException:
            pass

        return "None"

    def get_technology_stack(self, url):
        try:
            tech = self.wt.start_from_url(url)['tech']
            tech_list = []
            for i in tech:
                tech_list.append(i['name'])
            return tech_list
        except webtech.utils.ConnectionException:
            return []

    def _get_ips_from_cidr(self):
        ips = []
        try:
            network = ipaddress.IPv4Network(self.cidr)
            for ip in network:
                ips.append(str(ip))
        except ValueError as e:
            pass
        return ips
