from django.apps import AppConfig


class baseConfig(AppConfig):
    name = 'base'
