from .models import *
from rest_framework.decorators import api_view
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.db.models import Q
from .code import Computate
from .serializers import *
from ipaddress import ip_network
from django.http import HttpResponse
from django.contrib.auth import logout
from django.conf import settings
import requests
import io
import MySQLdb
import csv
import json
import os
import zipfile

# Define the Tasks class


class Tasks:
    def __init__(self):
        self.tasks = {}  # List to store tasks

    def start(self, list):
        obj = Computate(list)  # Create an instance of the Computate class
        self.tasks[list.id] = obj  # Add the task to the list of tasks
        return list.id  # Return the index of the added task


main_obj = Tasks()  # Create an instance of the Tasks class


config = open('config.json', 'r')  # Open the config file
config = json.load(config)  # Load the config file


# view for search
@api_view(['POST', 'GET'])
@login_required(login_url='/login')
def search(request):
    if request.user.is_superuser:
        q = request.GET.get('q') if request.GET.get('q') is not None else ''
        ips = IP.objects.filter(
            Q(ip__icontains=q) |
            Q(https_title__icontains=q) |
            Q(http_title__icontains=q) |
            Q(cn__icontains=q) |
            Q(org__icontains=q) |
            Q(asn__icontains=q) |
            Q(country__icontains=q) |
            Q(ip_range_ref__ip_range__icontains=q)
        )
        context = {'ip': ips}
        return render(request, 'base/tables_ip.html', context)
    else:
        return render(request, 'base/error.html')

# API view for home
@api_view(['POST', 'GET'])
@login_required(login_url='/login')
def home(request):
    if not request.user.is_superuser:
        return render(request, 'base/error.html')

    if request.method == 'POST':
        ip_range = request.POST.get('ip_range')
        try:
            list(ip_network(ip_range).hosts())
            print(ip_range)
        except:
            return redirect('/')

        url = "http://apitokenip.pythonanywhere.com/api/agent/ipadd/"
        payload = json.dumps({"ip_range": ip_range})
        headers = {
            'Authorization': config['token'],
            'Content-Type': 'application/json',
        }

        response = requests.post(url, headers=headers, data=payload)
        response_json = response.json()
        external_id = response_json['id']
        print(external_id)

        obj = IpRange(ip_range=ip_range, external=external_id)
        obj.save()
        main_obj.start(obj)
        main_obj.tasks[obj.id].start_all()
        return redirect('/results/' + str(obj.id) + '/')

    total_ip_range = IpRange.objects.all().count()
    total_ip = IP.objects.all().count()
    latest_ips = IP.objects.all().order_by('-id')[0:5]
    weekdays = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    weekly_counts = [IpRange.objects.filter(created=i+1).count() for i in range(7)]
    running_tasks = [task.id for task in main_obj.tasks.values() if task.status != "Saved"]
    ip_range_objs = IpRange.objects.filter(id__in=running_tasks)
    ip_down = IP.objects.filter(http_status="None", https_status="None").count()
    ip_up = total_ip - ip_down

    context = {
        'total_ip_range': total_ip_range,
        'ip_range_objs': ip_range_objs,
        'total_ip': total_ip,
        'ip_up': ip_up,
        'ip_down': ip_down,
        'ip': latest_ips,
        'weekdays': weekdays,
        'weekly_counts': weekly_counts
    }
    return render(request, 'base/index.html', context)

# View for the table
@login_required(login_url='/login')
def table(request):
    if request.user.is_superuser:
        ip_range = IpRange.objects.all()
        context = {'ip_ranges': ip_range}
        return render(request, 'base/tables.html', context)
    else:
        return render(request, 'base/error.html')

# View for the IP table
@login_required(login_url='/login')
def table_ip(request):
    if request.user.is_superuser:
        all_obj = IP.objects.all()
        context = {'ip': all_obj}
        return render(request, 'base/tables_ip.html', context)
    else:
        return render(request, 'base/error.html')

# View for GUI results
@login_required(login_url='/login')
def result_gui(request, pk):
    if not request.user.is_superuser:
        return render(request, 'base/error.html')

    try:
        task = main_obj.tasks[int(pk)]
    except KeyError:
        try:
            obj = IpRange.objects.get(id=pk)
            ip = list(IP.objects.filter(ip_range_ref=obj.id))
            id = obj.id
            status = "Done"
            percentage = 100.0
            return render(request, 'base/process.html', {
                "ip": ip, "status": status, "percentage": percentage,
                "iprange": obj.ip_range, "ip_range_id": id, "id": id, "json": False
            })
        except Exception as e:
            print(e)
            return render(request, 'base/error.html')

    if task.status == "Saved":
        obj = IpRange.objects.get(id=pk)
        ip = list(IP.objects.filter(ip_range_ref=obj.id))
        id = obj.id
        status = "Done"
        percentage = 100.0
        return render(request, 'base/process.html', {
            "ip": ip, "status": status, "percentage": percentage,
            "iprange": obj.ip_range, "ip_range_id": id, "id": id, "json": False
        })

    id = task.id
    ip = [[i['ip'], i['country'], i['cn']] for i in task.info]
    status = task.status
    percentage = task.percentage

    if task.status != "Saved" and percentage == 100.0:
        serializer = IPSerializer(data=task.info, many=True)
        if serializer.is_valid():
            serializer.save()
            print("Saved")
            csv_file = 'error/' + str(id) + '.csv'

            fieldnames = ["IP", "Error", "Line", "File"]

            with open(csv_file, mode="w", newline="") as file:
                writer = csv.DictWriter(file, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(task.error)

            temp_json = [dict(i, ip_range_ref=task.external) for i in task.info]

            url = "http://apitokenip.pythonanywhere.com/api/agent/data/"
            payload = json.dumps(temp_json)
            headers = {
                'Authorization': config['token'],
                'Content-Type': 'application/json',
            }
            response = requests.post(url, headers=headers, data=payload)
            print(response.json())

            task.status = "Saved"
        else:
            print(serializer.errors)

    return render(request, 'base/process.html', {
        "cool": ip, "status": status, "percentage": percentage,
        "iprange": task.cidr, "ip_range_id": task.id, "id": id, "json": True
    })

# View for handling 404 error
def error_404_view(request, exception):
    return render(request, 'base/error.html')

# Logout view


@login_required
def logout_user(request):
    logout(request)
    return redirect("/")


@login_required(login_url='/login')
def download(request):
    # Database credentials
    host = settings.DATABASES['default']['HOST']
    port = int(settings.DATABASES['default']['PORT'])
    user = settings.DATABASES['default']['USER']
    password = settings.DATABASES['default']['PASSWORD']
    database = settings.DATABASES['default']['NAME']

    # Establish a connection to the MySQL server
    conn = MySQLdb.connect(host=host, port=port, user=user,
                           passwd=password, db=database)

    # Create a cursor
    cursor = conn.cursor()

    # Get a list of all tables in the database
    cursor.execute("SHOW TABLES;")
    tables = cursor.fetchall()

    # Create a directory to store the SQL files
    backup_directory = os.path.join(settings.BASE_DIR, 'backup')
    os.makedirs(backup_directory, exist_ok=True)

    # Export each table as a separate SQL file
    for table in tables:
        table_name = table[0]
        dump_filepath = os.path.join(backup_directory, f'{table_name}.sql')
        dump_query = f"SELECT * INTO OUTFILE '{dump_filepath}' FROM {table_name};"
        cursor.execute(dump_query)

    # Close the cursor and connection
    cursor.close()
    conn.close()

    # Create a ZIP archive containing all the SQL files
    zip_filepath = os.path.join(settings.BASE_DIR, 'backup.zip')
    with zipfile.ZipFile(zip_filepath, 'w') as zip_file:
        for table in tables:
            table_name = table[0]
            dump_filepath = os.path.join(backup_directory, f'{table_name}.sql')
            zip_file.write(dump_filepath, arcname=f'{table_name}.sql')

    # Open the ZIP archive
    zip_file = open(zip_filepath, 'rb')

    # Create a response with the ZIP archive as the attachment
    response = HttpResponse(zip_file, content_type='application/zip')
    response['Content-Disposition'] = 'attachment; filename="backup.zip"'

    # Close and delete the ZIP file
    zip_file.close()
    os.remove(zip_filepath)

    # Remove the backup directory
    os.system(f"rm -r {backup_directory}")

    # Return the response
    return response

# View for showing details of an IP
@login_required
def ip_detail(request, pk):
    if request.user.is_superuser:
        ips = IP.objects.filter(id=pk)
        context = {'ip': ips}
        return render(request, 'base/ip.html', context)
    else:
        return render(request, 'base/error.html')

@login_required
def download_ip(request):
    # Connect to the MySQL database
    conn = MySQLdb.connect(
        host=settings.DATABASES['default']['HOST'],
        port=int(settings.DATABASES['default']['PORT']),
        user=settings.DATABASES['default']['USER'],
        passwd=settings.DATABASES['default']['PASSWORD'],
        db=settings.DATABASES['default']['NAME']
    )

    # Create a cursor
    cursor = conn.cursor()

    # Execute the SQL query to select all rows from the table
    cursor.execute('SELECT * FROM base_ip')

    # Fetch all rows from the cursor
    rows = cursor.fetchall()

    # Create a CSV file in memory
    csv_file = io.StringIO()

    # Create a CSV writer
    writer = csv.writer(csv_file)

    # Write the rows to the CSV file
    writer.writerows(rows)

    # Seek to the beginning of the CSV file
    csv_file.seek(0)

    # Create a HttpResponse object with the CSV file as the response body
    response = HttpResponse(csv_file, content_type='text/csv')

    # Set the response's filename
    response['Content-Disposition'] = 'attachment; filename="ips.csv"'

    # Close the cursor and connection
    cursor.close()
    conn.close()

    # Return the response
    return response

@login_required
def download_ip_of_range(request, pk):
    # Connect to the MySQL database
    conn = MySQLdb.connect(
        host=settings.DATABASES['default']['HOST'],
        port=int(settings.DATABASES['default']['PORT']),
        user=settings.DATABASES['default']['USER'],
        passwd=settings.DATABASES['default']['PASSWORD'],
        db=settings.DATABASES['default']['NAME']
    )

    # Create a cursor
    cursor = conn.cursor()

    # Execute the SQL query to select rows where ip_range_ref is equal to pk
    cursor.execute(f'SELECT * FROM base_ip INNER JOIN base_iprange ON base_ip.ip_range_ref_id = base_iprange.id WHERE base_iprange.id = {pk}')

    # Fetch all rows from the cursor
    rows = cursor.fetchall()

    # Create a CSV file in memory
    csv_file = io.StringIO()

    # Create a CSV writer
    writer = csv.writer(csv_file)

    # Write the rows to the CSV file
    writer.writerows(rows)

    # Seek to the beginning of the CSV file
    csv_file.seek(0)

    # Create a HttpResponse object with the CSV file as the response body
    response = HttpResponse(csv_file, content_type='text/csv')

    # Set the response's filename
    response['Content-Disposition'] = 'attachment; filename="ips.csv"'

    # Close the cursor and connection
    cursor.close()
    conn.close()

    # Return the response
    return response

@login_required
def download_ip_range(request):
    # Connect to the MySQL database
    conn = MySQLdb.connect(
        host=settings.DATABASES['default']['HOST'],
        port=int(settings.DATABASES['default']['PORT']),
        user=settings.DATABASES['default']['USER'],
        passwd=settings.DATABASES['default']['PASSWORD'],
        db=settings.DATABASES['default']['NAME']
    )

    # Create a cursor
    cursor = conn.cursor()

    # Execute the SQL query to select all rows from the table
    cursor.execute('SELECT * FROM base_ip_range')

    # Fetch all rows from the cursor
    rows = cursor.fetchall()

    # Create a CSV file in memory
    csv_file = io.StringIO()

    # Create a CSV writer
    writer = csv.writer(csv_file)

    # Write the rows to the CSV file
    writer.writerows(rows)

    # Seek to the beginning of the CSV file
    csv_file.seek(0)

    # Create a HttpResponse object with the CSV file as the response body
    response = HttpResponse(csv_file, content_type='text/csv')

    # Set the response's filename
    response['Content-Disposition'] = 'attachment; filename="ip_ranges.csv"'

    # Close the cursor and connection
    cursor.close()
    conn.close()

    # Return the response
    return response

def reportgen(request, pk):
    if request.user.is_superuser:
        from .Usman_Task import pdf_generate
        from .Usman_Task import gen_pdf
        try:
            obj = IpRange.objects.get(id=pk)
        except:
            return render(request, 'base/error.html')
        list = IP.objects.filter(ip_range_ref_id=pk)
        serializer = IPSerializer(list, many=True)
        pdf_generate(serializer.data)
        gen_pdf(str(pk))
        # Define the path to the generated PDF
        pdf_path = str(pk) + '.pdf'

        # Open the PDF file
        with open(pdf_path, 'rb') as f:
            response = HttpResponse(f.read(), content_type='application/pdf')
            response['Content-Disposition'] = f'inline; filename={str(pk)}.pdf'
        
        return response
    else:
        return render(request, 'base/error.html')